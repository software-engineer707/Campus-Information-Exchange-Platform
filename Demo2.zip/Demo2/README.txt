1.exact process of how to compile your source code and build a runnable file:
Our source code is tested to run in the following environments:
Windows10-64bit
Navicat12.018.0
jdk 8.0.1310.11
eclipse-jee-2019-03-R-win64
apache-tomcat-7.0.94

2.Where to find the runnable file if you already supplied one��
Runnable files are included in code files.

3.How exactly to run the runnable��what are the allowed input parameters:
ֻ��Ҫ�û�ע���Լ����˻�Ȼ���½���ɡ�

4.if it is necessary to authenticate the user, then list some example user IDs and passwords that will work:
For example:
username:xm     password:123
username:admin  password:123

5.describe the allowed values of all parameters that need to be entered while running your prgram:
Users only need to log in to their accounts. If there are incorrect input values, the system will not give feedback.




    |
    +-----> doc           // documentation plus Report #3, presentation slides, etc.
    |
    +-----> design        // UML diagrams
    |
    +--+--> code          // project code
       |
       +-------> java     // Java source code
       |
       +-------> classes  // compiled Java classes
       |
       +-------> images   // images and button icons
       |
       +-------> data     // (database) files with example data
       |
       +-------> run      // scripts and/or HTML filess
    |
    +-----> tests         // unit tests for the project code (and any other tests)
    |
    +-----> data          // data collected or need for the project