/*
Navicat MySQL Data Transfer

Source Server         : local
Source Server Version : 50528
Source Host           : localhost:3306
Source Database       : productauctionssh_db

Target Server Type    : MYSQL
Target Server Version : 50528
File Encoding         : 65001

Date: 2019-05-19 17:58:36
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `car`
-- ----------------------------
DROP TABLE IF EXISTS `car`;
CREATE TABLE `car` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `memberid` varchar(255) DEFAULT NULL,
  `goodsid` varchar(255) DEFAULT NULL,
  `savetime` varchar(255) DEFAULT NULL,
  `saver` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of car
-- ----------------------------
INSERT INTO `car` VALUES ('7', '7', '23', '2019-01-02 15:57:01', '1');

-- ----------------------------
-- Table structure for `gongneng`
-- ----------------------------
DROP TABLE IF EXISTS `gongneng`;
CREATE TABLE `gongneng` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `fatherid` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `delstatus` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of gongneng
-- ----------------------------
INSERT INTO `gongneng` VALUES ('2', '商品信息管理', '0', '', '0');
INSERT INTO `gongneng` VALUES ('3', '商品管理', '2', 'goodslist.jsp', '0');
INSERT INTO `gongneng` VALUES ('6', '人员管理', '0', '', '0');
INSERT INTO `gongneng` VALUES ('7', '会员管理', '6', 'huiyuanmanager.jsp', '0');
INSERT INTO `gongneng` VALUES ('10', '拍卖管理', '2', 'dingdanmanager.jsp', '1');
INSERT INTO `gongneng` VALUES ('11', '管理员管理', '6', 'usersmanager.jsp', '0');
INSERT INTO `gongneng` VALUES ('12', '基础信息', '0', '', '0');
INSERT INTO `gongneng` VALUES ('13', '友情链接管理', '12', 'yqljlist.jsp', '0');
INSERT INTO `gongneng` VALUES ('14', '系统公告管理', '12', 'noticelist.jsp', '0');
INSERT INTO `gongneng` VALUES ('15', '焦点图管理', '12', 'imglist.jsp', '0');
INSERT INTO `gongneng` VALUES ('16', '投诉管理', '12', 'liuyanlist.jsp', '0');
INSERT INTO `gongneng` VALUES ('17', '举报管理', '12', 'jubaolist.jsp', '1');
INSERT INTO `gongneng` VALUES ('18', '系统设置', '0', '', '0');
INSERT INTO `gongneng` VALUES ('19', '修改密码', '18', 'modifypw.jsp', '0');
INSERT INTO `gongneng` VALUES ('20', '测试', '0', '', '1');
INSERT INTO `gongneng` VALUES ('21', '测试', '20', 'aa.jsp', '1');
INSERT INTO `gongneng` VALUES ('22', '商品类别管理', '2', 'producttypelist.jsp', '0');
INSERT INTO `gongneng` VALUES ('23', '评价管理', '0', '', '0');
INSERT INTO `gongneng` VALUES ('24', '评价信息', '23', 'pingjialist.jsp', '0');
INSERT INTO `gongneng` VALUES ('25', '交流管理', '12', 'jiaoliulist.jsp', '0');

-- ----------------------------
-- Table structure for `goods`
-- ----------------------------
DROP TABLE IF EXISTS `goods`;
CREATE TABLE `goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goodsname` varchar(255) DEFAULT NULL,
  `price` int(255) DEFAULT NULL,
  `jiajia` int(11) DEFAULT NULL,
  `shuishou` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `content` text,
  `delstatus` varchar(255) DEFAULT NULL,
  `stime` varchar(255) DEFAULT NULL,
  `etime` varchar(255) DEFAULT NULL,
  `maxprice` int(255) DEFAULT NULL,
  `memberid` varchar(255) DEFAULT NULL,
  `cs` int(11) DEFAULT NULL,
  `shstatus` varchar(255) DEFAULT NULL,
  `chengdu` varchar(255) DEFAULT NULL,
  `buytime` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of goods
-- ----------------------------
INSERT INTO `goods` VALUES ('29', 'dfdfdfd', '0', '0', '0', '3', '/productauctionssh/upfile/no.jpg', '正在出售', 'sdfsdfsdfsdf', '0', '2019-05-19 17:12:00', null, '0', '1', '14', '待审核', 'extremely difficult', '2019-05-03');

-- ----------------------------
-- Table structure for `imgv`
-- ----------------------------
DROP TABLE IF EXISTS `imgv`;
CREATE TABLE `imgv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `img` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of imgv
-- ----------------------------
INSERT INTO `imgv` VALUES ('2', '/productauctionssh/upfile/20171216151117.jpg');
INSERT INTO `imgv` VALUES ('3', '/productauctionssh/upfile/20171216151101.jpg');
INSERT INTO `imgv` VALUES ('4', '/productauctionssh/upfile/20171216151027.jpg');

-- ----------------------------
-- Table structure for `jiaoliu`
-- ----------------------------
DROP TABLE IF EXISTS `jiaoliu`;
CREATE TABLE `jiaoliu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goodsid` varchar(255) DEFAULT NULL,
  `memberid` varchar(255) DEFAULT NULL,
  `content` text,
  `lsavetime` varchar(255) DEFAULT NULL,
  `hcontent` text,
  `hsavetime` varchar(255) DEFAULT NULL,
  `saver` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of jiaoliu
-- ----------------------------
INSERT INTO `jiaoliu` VALUES ('5', '23', '7', '这个能不能便宜点？我是jack', '2019-01-02 15:54:52', '不卖你jack', '2019-01-02 15:56:12', '1');
INSERT INTO `jiaoliu` VALUES ('6', '23', '8', '我不还价，我是zhangsan', '2019-01-02 15:55:26', '好，我卖你', '2019-01-02 15:56:23', '1');

-- ----------------------------
-- Table structure for `jingjia`
-- ----------------------------
DROP TABLE IF EXISTS `jingjia`;
CREATE TABLE `jingjia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gid` varchar(255) DEFAULT NULL,
  `memberid` varchar(255) DEFAULT NULL,
  `chuprice` int(11) DEFAULT NULL,
  `delstatus` varchar(255) DEFAULT NULL,
  `savetime` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of jingjia
-- ----------------------------
INSERT INTO `jingjia` VALUES ('4', '16', '7', '2200', '0', '2019-01-30 17:23:42');
INSERT INTO `jingjia` VALUES ('5', '16', '7', '2400', '0', '2019-01-30 17:24:13');
INSERT INTO `jingjia` VALUES ('6', '16', '7', '2600', '0', '2019-01-30 21:22:32');
INSERT INTO `jingjia` VALUES ('7', '22', '1', '27', '0', '2019-01-30 22:38:12');
INSERT INTO `jingjia` VALUES ('8', '22', '7', '29', '0', '2019-01-30 22:38:47');
INSERT INTO `jingjia` VALUES ('9', '15', '7', '2100', '0', '2019-01-30 22:47:26');

-- ----------------------------
-- Table structure for `juese`
-- ----------------------------
DROP TABLE IF EXISTS `juese`;
CREATE TABLE `juese` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `delstatus` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of juese
-- ----------------------------
INSERT INTO `juese` VALUES ('1', '超级管理员', '0');
INSERT INTO `juese` VALUES ('2', '普通管理员', '0');

-- ----------------------------
-- Table structure for `lishi`
-- ----------------------------
DROP TABLE IF EXISTS `lishi`;
CREATE TABLE `lishi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gid` varchar(255) DEFAULT NULL,
  `memberid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of lishi
-- ----------------------------
INSERT INTO `lishi` VALUES ('25', '29', '1');

-- ----------------------------
-- Table structure for `liuyan`
-- ----------------------------
DROP TABLE IF EXISTS `liuyan`;
CREATE TABLE `liuyan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `memberid` varchar(255) DEFAULT NULL,
  `content` text,
  `lsavetime` varchar(255) DEFAULT NULL,
  `hcontent` text,
  `adminid` varchar(255) DEFAULT NULL,
  `hsavetime` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of liuyan
-- ----------------------------
INSERT INTO `liuyan` VALUES ('5', '1', '那个很吊，他还打我，你管不管？', '2019-01-02 15:59:05', '我去找他', 'admin', '2019-01-02 15:59:15');
INSERT INTO `liuyan` VALUES ('6', '1', 'sdsfsdfdsfsdf', '2019-05-19 17:44:14', '', '', '');
INSERT INTO `liuyan` VALUES ('7', '1', 'sdsfsdfdsfsdf', '2019-05-19 17:46:22', '', '', '');

-- ----------------------------
-- Table structure for `member`
-- ----------------------------
DROP TABLE IF EXISTS `member`;
CREATE TABLE `member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uname` varchar(255) DEFAULT NULL,
  `upass` varchar(255) DEFAULT NULL,
  `realname` varchar(255) DEFAULT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `age` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `addr` varchar(255) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  `savetime` varchar(255) DEFAULT NULL,
  `delstatus` varchar(255) DEFAULT NULL,
  `yue` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of member
-- ----------------------------
INSERT INTO `member` VALUES ('1', 'xm', '123', '李白', '男', null, '13643290486', 'dd@126.com', '河北保定', '/productauctionssh/upfile/201304051943520002.jpg', '2019-01-28 20:29:35', '0', '909.3', '正常');
INSERT INTO `member` VALUES ('7', 'jack', '123', '冯涛', '女', null, '13893784349', 'jack@126.com', '武汉光谷广场', '/productauctionssh/upfile/201206261544220003.jpg', '2019-01-30 16:54:02', '0', '0', '禁用');
INSERT INTO `member` VALUES ('8', 'zhangsan', '123', '张三', '男', null, '13893784341', 'zhangsan@126.com', '武汉光谷广场', '/productauctionssh/upfile/201304051914080005.jpg', '2019-01-30 22:34:21', '0', '0', '正常');
INSERT INTO `member` VALUES ('9', 'lisi', '123', '李四', '女', null, '13893784349', 'lisi@126.com', '武汉光谷广场', '/productauctionssh/upfile/201405171715420005.jpg', '2019-01-02 15:41:22', '0', '0', '正常');

-- ----------------------------
-- Table structure for `notice`
-- ----------------------------
DROP TABLE IF EXISTS `notice`;
CREATE TABLE `notice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `content` text,
  `img` varchar(255) DEFAULT NULL,
  `savetime` varchar(255) DEFAULT NULL,
  `num` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of notice
-- ----------------------------
INSERT INTO `notice` VALUES ('1', 'qianggou', 'contentcontentcontentcontent', '/freshfoodshoppingssh/upload/nopic.jpg', '2019-01-28 20:29:35', '0');

-- ----------------------------
-- Table structure for `pingjia`
-- ----------------------------
DROP TABLE IF EXISTS `pingjia`;
CREATE TABLE `pingjia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `memberid` varchar(255) DEFAULT NULL,
  `goodsid` varchar(255) DEFAULT NULL,
  `content` text,
  `savetime` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pingjia
-- ----------------------------
INSERT INTO `pingjia` VALUES ('6', '8', '15', '这个我觉得还可以', '2019-01-30 22:45:57');
INSERT INTO `pingjia` VALUES ('7', '7', '15', '一般吧！不像你说的那个样子', '2019-01-30 22:46:54');
INSERT INTO `pingjia` VALUES ('8', '1', '24', '1212121212', '2019-05-19 15:47:44');
INSERT INTO `pingjia` VALUES ('9', '1', '24', '121212121', '2019-05-19 15:47:49');
INSERT INTO `pingjia` VALUES ('10', '1', '24', '', '2019-05-19 15:47:52');
INSERT INTO `pingjia` VALUES ('11', '1', '24', '1212121212112112', '2019-05-19 15:48:02');

-- ----------------------------
-- Table structure for `producttype`
-- ----------------------------
DROP TABLE IF EXISTS `producttype`;
CREATE TABLE `producttype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `typename` varchar(255) DEFAULT NULL,
  `delstatus` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of producttype
-- ----------------------------
INSERT INTO `producttype` VALUES ('3', 'books', '0');
INSERT INTO `producttype` VALUES ('4', 'News', '0');
INSERT INTO `producttype` VALUES ('6', 'Questions', '0');
INSERT INTO `producttype` VALUES ('7', '测试分类1', '1');

-- ----------------------------
-- Table structure for `qiugou`
-- ----------------------------
DROP TABLE IF EXISTS `qiugou`;
CREATE TABLE `qiugou` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `content` text,
  `memberid` varchar(255) DEFAULT NULL,
  `savetime` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qiugou
-- ----------------------------
INSERT INTO `qiugou` VALUES ('2', '诚求购挂件', '观音', '/productauctionssh/upfile/20180107155400.jpg', '11111111111', '1', '2019-01-02 11:06:57');
INSERT INTO `qiugou` VALUES ('3', '武侠小说', '天龙八部', '/productauctionssh/upfile/20180502154401.jpg', '1111111111', '7', '2019-01-02 15:53:41');

-- ----------------------------
-- Table structure for `shouquan`
-- ----------------------------
DROP TABLE IF EXISTS `shouquan`;
CREATE TABLE `shouquan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jsid` varchar(255) DEFAULT NULL,
  `gnid` varchar(255) DEFAULT NULL,
  `fatherid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of shouquan
-- ----------------------------
INSERT INTO `shouquan` VALUES ('29', '1', '3', '2');
INSERT INTO `shouquan` VALUES ('30', '1', '7', '6');
INSERT INTO `shouquan` VALUES ('31', '1', '11', '6');
INSERT INTO `shouquan` VALUES ('32', '1', '13', '12');
INSERT INTO `shouquan` VALUES ('33', '1', '14', '12');
INSERT INTO `shouquan` VALUES ('34', '1', '15', '12');
INSERT INTO `shouquan` VALUES ('35', '1', '16', '12');
INSERT INTO `shouquan` VALUES ('36', '1', '19', '18');
INSERT INTO `shouquan` VALUES ('37', '1', '22', '2');
INSERT INTO `shouquan` VALUES ('38', '1', '24', '23');
INSERT INTO `shouquan` VALUES ('39', '1', '25', '12');
INSERT INTO `shouquan` VALUES ('40', '2', '3', '2');
INSERT INTO `shouquan` VALUES ('41', '2', '7', '6');
INSERT INTO `shouquan` VALUES ('42', '2', '13', '12');
INSERT INTO `shouquan` VALUES ('43', '2', '14', '12');
INSERT INTO `shouquan` VALUES ('44', '2', '15', '12');
INSERT INTO `shouquan` VALUES ('45', '2', '19', '18');
INSERT INTO `shouquan` VALUES ('46', '2', '22', '2');

-- ----------------------------
-- Table structure for `sysuser`
-- ----------------------------
DROP TABLE IF EXISTS `sysuser`;
CREATE TABLE `sysuser` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `usertype` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `userpwd` varchar(255) DEFAULT NULL,
  `realname` varchar(255) DEFAULT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  `delstatus` varchar(255) DEFAULT NULL,
  `savetime` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sysuser
-- ----------------------------
INSERT INTO `sysuser` VALUES ('1', '1', 'admin', '123', '王老大', '男', '13643290486', 'admin@163.com', '/onlineorderingssh/upfile/u=2332039348,1866544533&fm=23&gp=0.jpg', '0', '2019-01-28 00:00:00');
INSERT INTO `sysuser` VALUES ('2', '2', 'root', '123', 'root', '男', '13798423810', 'root@126.com', '/productauctionssh/upfile/20.jpg', '0', '2019-01-28 00:00:00');
INSERT INTO `sysuser` VALUES ('3', '2', 'emp', '123', 'emp', '男', '134839212311', 'emp@126.com', '/freshfoodshoppingssh/upfile/201304051942500001.jpg', '1', '2019-01-28 00:00:00');

-- ----------------------------
-- Table structure for `yqlj`
-- ----------------------------
DROP TABLE IF EXISTS `yqlj`;
CREATE TABLE `yqlj` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yqlj
-- ----------------------------
